<footer>
  <hr>
  <small>Purchases made on this site are non-refundable.</small><br><br>
  <small>Design and Development by <a href="http://thereisnomedium.com" target="_blank">Large &#38; Small</a>, 2021.</small><br>
  <small>Powered by HTML, CSS, and <a href="https://getkirby.com">Kirby CMS</a>. Interested in making your own virtual moving sale? Download the code on <a href="">GitHub</a>.</small>
</footer>

</body>
</html>
