<?php

return [
    'email' => 'mcleanshannon.g@gmail.com',
    'language' => 'en',
    'name' => '',
    'role' => 'admin'
];