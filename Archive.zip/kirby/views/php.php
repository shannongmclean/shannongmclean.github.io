<?php include __DIR__ . '/snippets/header.php' ?>

  <p class="notice">
    This page is currently offline. We are very sorry for the inconvenience and will fix it as soon as possible.
  </p>
  <p class="admin-advice">
    Advice for developers and administrators:<br>
    Change the PHP version to 7.3, 7.4 or 8.0 (PHP 7.4 is recommended)
  </p>

<?php include __DIR__ . '/snippets/footer.php' ?>
